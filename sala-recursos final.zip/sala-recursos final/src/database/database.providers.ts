import { DataSource } from 'typeorm';
import { SnakeNamingStrategy } from 'typeorm-naming-strategies';

export const databaseProviders = [
  {
    provide: 'DATA_SOURCE',
    useFactory: async () => {
      const dataSource = new DataSource({
        type: 'mysql',
        host: 'localhost',
        port: 3306,
        username: 'root',
        password: '123456',
        database: 'sala_recursos',
        entities: [__dirname + '/../**/*.entity{.ts,.js}'],
        synchronize: true, // cria/atualiza as tabelas automaticamente
        logging: true,
        namingStrategy: new SnakeNamingStrategy(), // converte camelCase -> snake_case no banco
      });

      return dataSource.initialize();
    },
  },
];
