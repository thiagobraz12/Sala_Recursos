import { Global, Module } from '@nestjs/common';
import { databaseProviders } from './database.providers';

@Global() // torna o módulo visível globalmente, sem precisar importar em todos os módulos
@Module({
  providers: [...databaseProviders],
  exports: [...databaseProviders],
})
export class DatabaseModule {}
