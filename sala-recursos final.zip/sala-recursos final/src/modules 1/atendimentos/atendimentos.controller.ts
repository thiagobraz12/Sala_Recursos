import { Controller, Get, Post, Put, Delete, Param, Body, Render } from '@nestjs/common';
import { AtendimentosService } from './atendimentos.service';
import { Atendimento } from './atendimento.entity';

@Controller()
export class AtendimentosController {
  constructor(private readonly service: AtendimentosService) {}

  // Página .hbs
  @Get('/atendimentos')
  @Render('atendimentos')
  showAtendimentosPage() {
    return {};
  }

  // Helper: formata para DD-MM-YYYY
  private formatDate(input: string | Date | null | undefined): string | null {
    if (!input) return null;
    const d = input instanceof Date ? input : new Date(input);
    if (Number.isNaN(d.getTime())) return null;
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const yyyy = d.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
  }

  // API: pega todos e envia com data formatada
  @Get('api/atendimentos')
  async findAll() {
    const rows: Atendimento[] | any[] = await this.service.findAll();
    // mapeia e garante que data_atendimento venha como DD-MM-YYYY
    return rows.map(r => ({
      ...r,
      data_atendimento: this.formatDate(r.data_atendimento),
    }));
  }

  @Get('api/atendimentos/:id')
  async findOne(@Param('id') id: string) {
    const row = await this.service.findOne(+id);
    if (!row) return row;
    return {
      ...row,
      data_atendimento: this.formatDate(row.data_atendimento),
    };
  }

  @Post('api/atendimentos')
  create(@Body() body: any) {
    // console.log opcional para debug
    // console.log('📩 Body recebido pelo backend:', body);
    return this.service.create(body);
  }

  @Put('api/atendimentos/:id')
  update(@Param('id') id: string, @Body() body: Partial<Atendimento>) {
    return this.service.update(+id, body);
  }

  @Delete('api/atendimentos/:id')
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
