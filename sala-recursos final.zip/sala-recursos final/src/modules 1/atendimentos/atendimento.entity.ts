import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('atendimentos')
export class Atendimento {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  aluno: string; // nome do aluno

  @Column()
  profissional: string; // nome do profissional

  @Column({ type: 'date' })
  data_atendimento: string;

  @Column({ nullable: true })
  observacoes: string;
}
