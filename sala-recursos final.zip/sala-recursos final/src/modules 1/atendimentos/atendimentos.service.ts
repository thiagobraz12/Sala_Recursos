import { Injectable, Inject } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { Atendimento } from './atendimento.entity';

@Injectable()
export class AtendimentosService {
  private repo: Repository<Atendimento>;

  constructor(@Inject('DATA_SOURCE') private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Atendimento);
  }

  findAll(): Promise<Atendimento[]> {
    return this.repo.find();
  }

  findOne(id: number): Promise<Atendimento | null> {
    return this.repo.findOneBy({ id });
  }

  create(data: Partial<Atendimento>): Promise<Atendimento> {
    const atend = this.repo.create(data);
    return this.repo.save(atend);
  }

  async update(id: number, data: Partial<Atendimento>): Promise<Atendimento | null> {
    await this.repo.update(id, data);
    return this.findOne(id);
  }

  remove(id: number) {
    return this.repo.delete(id);
  }
}
