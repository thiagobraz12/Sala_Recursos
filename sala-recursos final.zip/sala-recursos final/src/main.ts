import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { NestExpressApplication } from '@nestjs/platform-express';
import { join } from 'path';
import hbs from 'hbs';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);

  //app.set('view options', { layout: 'layout' });
  
  // Pasta PUBLIC
  app.useStaticAssets(join(__dirname, '..', 'public'));


  // Definir pasta de views
  app.setBaseViewsDir(join(__dirname, '..', 'src', 'views'));

  // Definir engine
  app.setViewEngine('hbs');

  // Registrar PARTIALS corretamente
  hbs.registerPartials(join(__dirname, '..', 'src', 'views', 'partials'));

  // Registrar helpers (obrigatório por causa do ifEquals da sidebar)
  hbs.registerHelper('ifEquals', function(a, b, opts) {
    return a === b ? opts.fn(this) : opts.inverse(this);
  });

  // Registrar pasta STATIC
  //app.useStaticAssets(join(__dirname, '..', 'public'));

  await app.listen(3000);
  console.log('🚀 Rodando em http://localhost:3000');
}

bootstrap();
