
import { Module } from '@nestjs/common';
import { ServeStaticModule } from '@nestjs/serve-static';
import { join } from 'path';

import { DatabaseModule } from './database/database.module';

import { AlunosModule } from './modules/alunos/alunos.module';
import { ResponsaveisModule } from './modules 3/responsaveis/responsaveis.module';
import { EscolasModule } from './modules 4/escolas/escolas.module';
import { ProfissionaisModule } from './modules 5/profissionais/profissionais.module';
import { CidsModule } from './modules 2/cids/cids.module';
import { AtendimentosModule } from './modules 1/atendimentos/atendimentos.module';

import { AppController } from './app.controller';
import { AppService } from './app.service';

@Module({
  imports: [
    ServeStaticModule.forRoot({
      rootPath: join(process.cwd(), 'public'),
      serveRoot: '/static',  // << ESSENCIAL
    }),

    DatabaseModule,

    AlunosModule,
    ResponsaveisModule,
    EscolasModule,
    ProfissionaisModule,
    CidsModule,
    AtendimentosModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
