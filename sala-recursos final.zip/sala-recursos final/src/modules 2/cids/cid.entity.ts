import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('cids')
export class Cid {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  codigo: string;

  @Column()
  descricao: string;
}
