
import { Controller, Get, Post, Put, Delete, Param, Body, Render } from '@nestjs/common';
import { CidsService } from './cids.service';
import { Cid } from './cid.entity';

@Controller()
export class CidsController {
  constructor(private readonly service: CidsService) {}

  // ----------------------------
  // 🔹 ROTA PARA EXIBIR O ARQUIVO cid.hbs
  // ----------------------------
  @Get('/cid')
  @Render('cid')
  showCidPage() {
    return {}; // se futuramente quiser enviar dados
  }

  // ----------------------------
  // 🔹 ROTAS DA API (REST)
  // ----------------------------
  @Get('api/cids')
  findAll(): Promise<Cid[]> {
    return this.service.findAll();
  }

  @Get('api/cids/:id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(+id);
  }

  @Post('api/cids')
  create(@Body() body: Partial<Cid>) {
    return this.service.create(body);
  }

  @Put('api/cids/:id')
  update(@Param('id') id: string, @Body() body: Partial<Cid>) {
    return this.service.update(+id, body);
  }

  @Delete('api/cids/:id')
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
