import { Module } from '@nestjs/common';
import { CidsService } from './cids.service';
import { CidsController } from './cids.controller';

@Module({
  controllers: [CidsController],
  providers: [CidsService],
})
export class CidsModule {}
