import { Injectable, Inject } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { Cid } from './cid.entity';

@Injectable()
export class CidsService {
  private repo: Repository<Cid>;

  constructor(@Inject('DATA_SOURCE') private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Cid);
  }

  findAll() {
    return this.repo.find();
  }

  findOne(id: number) {
    return this.repo.findOneBy({ id });
  }

  create(data: Partial<Cid>) {
    const novo = this.repo.create(data);
    return this.repo.save(novo);
  }

  async update(id: number, data: Partial<Cid>) {
    await this.repo.update(id, data);
    return this.repo.findOneBy({ id });
  }

  remove(id: number) {
    return this.repo.delete(id);
  }
}
