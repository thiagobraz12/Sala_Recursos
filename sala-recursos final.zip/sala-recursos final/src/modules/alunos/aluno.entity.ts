import { Entity, PrimaryGeneratedColumn, Column, OneToMany } from 'typeorm';
import { Responsavel } from '../../modules 3/responsaveis/responsavel.entity';

@Entity('alunos')
export class Aluno {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nome: string;

  @Column()
  idade: number;

  @Column()
  turma: string;

  @Column()
  escola: string;

  // lado inverso: um aluno pode ter vários responsáveis
  @OneToMany(() => Responsavel, (responsavel) => responsavel.aluno)
  responsaveis: Responsavel[];
}

