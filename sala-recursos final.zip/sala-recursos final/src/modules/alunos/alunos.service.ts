import { Injectable, Inject } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { Aluno } from './aluno.entity';

@Injectable()
export class AlunosService {
  private repo: Repository<Aluno>;

  constructor(@Inject('DATA_SOURCE') private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Aluno);
  }

  findAll(): Promise<Aluno[]> {
    return this.repo.find();
  }

  findOne(id: number): Promise<Aluno | null> {
    return this.repo.findOneBy({ id });
  }

  create(data: Partial<Aluno>): Promise<Aluno> {
    const aluno = this.repo.create(data);
    return this.repo.save(aluno);
  }

  async update(id: number, data: Partial<Aluno>): Promise<Aluno | null> {
    await this.repo.update(id, data);
    return this.findOne(id);
  }

  remove(id: number) {
    return this.repo.delete(id);
  }
}
