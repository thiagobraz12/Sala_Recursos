
import { Controller, Get, Post, Put, Delete, Param, Body, Render } from '@nestjs/common';
import { AlunosService } from './alunos.service';
import { Aluno } from './aluno.entity';

@Controller()
export class AlunosController {
  constructor(private readonly alunosService: AlunosService) {}

  // 🌐 Página principal dos alunos (HBS)
  @Get('alunos')
  @Render('alunos') // alunos.hbs
  paginaAlunos() {
    return { title: 'Cadastro de Alunos' };
  }

  // ==========================
  // 📌 ROTAS API (REST)
  // ==========================

  @Get('api/alunos')
  findAll(): Promise<Aluno[]> {
    return this.alunosService.findAll();
  }

  @Get('api/alunos/:id')
  findOne(@Param('id') id: string) {
    return this.alunosService.findOne(+id);
  }

  @Post('api/alunos')
  create(@Body() body: Partial<Aluno>) {
    return this.alunosService.create(body);
  }

  @Put('api/alunos/:id')
  update(@Param('id') id: string, @Body() body: Partial<Aluno>) {
    return this.alunosService.update(+id, body);
  }

  @Delete('api/alunos/:id')
  remove(@Param('id') id: string) {
    return this.alunosService.remove(+id);
  }
}
