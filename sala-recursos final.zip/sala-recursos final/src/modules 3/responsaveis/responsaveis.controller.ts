
import { Controller, Get, Post, Put, Delete, Param, Body, Render } from '@nestjs/common';
import { ResponsaveisService } from './responsaveis.service';
import { Responsavel } from './responsavel.entity';

@Controller()
export class ResponsaveisController {
  constructor(private readonly service: ResponsaveisService) {}

  // --------------------------------------
  // 🔹 Rota para exibir a página HBS
  // --------------------------------------
  @Get('/responsaveis')
  @Render('responsaveis')
  showResponsaveisPage() {
    return {};
  }

  // --------------------------------------
  // 🔹 Rotas da API REST
  // --------------------------------------
  @Get('api/responsaveis')
  findAll(): Promise<Responsavel[]> {
    return this.service.findAll();
  }

  @Get('api/responsaveis/:id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(+id);
  }

  @Post('api/responsaveis')
  create(@Body() body: Partial<Responsavel>) {
    return this.service.create(body);
  }

  @Put('api/responsaveis/:id')
  update(@Param('id') id: string, @Body() body: Partial<Responsavel>) {
    return this.service.update(+id, body);
  }

  @Delete('api/responsaveis/:id')
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
