import { Entity, PrimaryGeneratedColumn, Column, ManyToOne } from 'typeorm';
import { Aluno } from '../../modules/alunos/aluno.entity';

@Entity('responsaveis')
export class Responsavel {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 100 })
  nome: string;

  @Column({ length: 20 })
  telefone: string;

  @Column({ length: 100, nullable: true })
  email: string;

  @ManyToOne(() => Aluno, (aluno) => aluno.responsaveis, { nullable: true, onDelete: 'SET NULL' })
  aluno: Aluno;
}




