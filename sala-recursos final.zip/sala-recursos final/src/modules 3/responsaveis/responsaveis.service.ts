import { Injectable, Inject } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { Responsavel } from './responsavel.entity';

@Injectable()
export class ResponsaveisService {
  private repo: Repository<Responsavel>;

  constructor(@Inject('DATA_SOURCE') private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Responsavel);
  }

  findAll() {
    return this.repo.find();
  }

  findOne(id: number) {
    return this.repo.findOneBy({ id });
  }

  create(data: Partial<Responsavel>) {
    const novo = this.repo.create(data);
    return this.repo.save(novo);
  }

  async update(id: number, data: Partial<Responsavel>) {
    await this.repo.update(id, data);
    return this.repo.findOneBy({ id });
  }

  remove(id: number) {
    return this.repo.delete(id);
  }
}
