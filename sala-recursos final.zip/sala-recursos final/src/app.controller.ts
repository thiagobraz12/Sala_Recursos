
import { Controller, Get, Render } from '@nestjs/common';

@Controller()
export class AppController {

  @Get()
  @Render('index')
  root() {
    return {};
  }

  @Get('login')
  @Render('login')
  login() {
    return {};
  }

  @Get('dashboard')
  @Render('dashboard')
  dashboard() {
    return {};
  }

  @Get('alunos')
  @Render('alunos')
  alunos() {
    return {};
  }

  @Get('responsaveis')
  @Render('responsaveis')
  responsaveis() {
    return {};
  }

  @Get('escolas')
  @Render('escolas')
  escolas() {
    return {};
  }

  @Get('profissionais')
  @Render('profissionais')
  profissionais() {
    return {};
  }

  @Get('cid')
  @Render('cid')
  cid() {
    return {};
  }

  @Get('atendimentos')
  @Render('atendimentos')
  atendimentos() {
    return {};
  }

  @Get('sobre')
  @Render('sobre')
  sobre() {
    return {};
  }
}
