import { Entity, Column, PrimaryGeneratedColumn } from 'typeorm';

@Entity('profissionais')
export class Profissional {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  nome: string;

  @Column()
  especialidade: string;

  @Column({ nullable: true })
  email: string;

  @Column({ nullable: true })
  telefone: string;
}

