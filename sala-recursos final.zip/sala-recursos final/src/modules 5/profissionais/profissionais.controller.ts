import { Controller, Get, Post, Put, Delete, Param, Body, Render } from '@nestjs/common';
import { ProfissionaisService } from './profissionais.service';
import { Profissional } from './profissional.entity';

@Controller()
export class ProfissionaisController {
  constructor(private readonly service: ProfissionaisService) {}

  // --------------------------------------
  // 🔹 Página principal (VIEW HBS)
  // --------------------------------------
  @Get('/profissionais')
  @Render('profissionais')
  showProfissionaisPage() {
    return {}; // pode retornar dados caso necessário
  }

  // --------------------------------------
  // 🔹 Rotas da API REST
  // --------------------------------------
  @Get('/api/profissionais')
  findAll(): Promise<Profissional[]> {
    return this.service.findAll();
  }

  @Get('/api/profissionais/:id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(+id);
  }

  @Post('/api/profissionais')
  create(@Body() body: Partial<Profissional>) {
    return this.service.create(body);
  }

  @Put('/api/profissionais/:id')
  update(@Param('id') id: string, @Body() body: Partial<Profissional>) {
    return this.service.update(+id, body);
  }

  @Delete('/api/profissionais/:id')
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
