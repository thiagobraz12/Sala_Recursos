import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity('escolas')
export class Escola {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ length: 150 })
  nome: string;

  @Column({ length: 200, nullable: true })
  endereco: string;

  @Column({ length: 100, nullable: true })
  telefone: string;
}
