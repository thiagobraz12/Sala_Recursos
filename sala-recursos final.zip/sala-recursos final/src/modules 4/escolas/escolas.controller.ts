import { Controller, Get, Post, Put, Delete, Param, Body, Render } from '@nestjs/common';
import { EscolasService } from './escolas.service';
import { Escola } from './escola.entity';

@Controller()
export class EscolasController {
  constructor(private readonly service: EscolasService) {}

  // ----------------------------
  // 🔹 ROTA PARA EXIBIR O ARQUIVO escolas.hbs
  // ----------------------------
  @Get('/escolas')
  @Render('escolas')
  showEscolasPage() {
    return {};
  }

  // ----------------------------
  // 🔹 ROTAS DA API (REST)
  // ----------------------------
  @Get('api/escolas')
  findAll(): Promise<Escola[]> {
    return this.service.findAll();
  }

  @Get('api/escolas/:id')
  findOne(@Param('id') id: string) {
    return this.service.findOne(+id);
  }

  @Post('api/escolas')
  create(@Body() body: Partial<Escola>) {
    return this.service.create(body);
  }

  @Put('api/escolas/:id')
  update(@Param('id') id: string, @Body() body: Partial<Escola>) {
    return this.service.update(+id, body);
  }

  @Delete('api/escolas/:id')
  remove(@Param('id') id: string) {
    return this.service.remove(+id);
  }
}
