import { Injectable, Inject } from '@nestjs/common';
import { DataSource, Repository } from 'typeorm';
import { Escola } from './escola.entity';

@Injectable()
export class EscolasService {
  private repo: Repository<Escola>;

  constructor(@Inject('DATA_SOURCE') private dataSource: DataSource) {
    this.repo = this.dataSource.getRepository(Escola);
  }

  findAll() {
    return this.repo.find();
  }

  findOne(id: number) {
    return this.repo.findOneBy({ id });
  }

  create(data: Partial<Escola>) {
    const novo = this.repo.create(data);
    return this.repo.save(novo);
  }

  async update(id: number, data: Partial<Escola>) {
    await this.repo.update(id, data);
    return this.repo.findOneBy({ id });
  }

  remove(id: number) {
    return this.repo.delete(id);
  }
}
